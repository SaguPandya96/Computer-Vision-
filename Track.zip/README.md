# CSImageViewer

This C# program allows one to read and write color and grayscale images.
It's purpose is to provide a basis for image processing and analysis.
