var searchData=
[
  ['mean_1',['mean',['../class_start_1_1_helper_functions.html#a700804e35af8fbd532fc3a5cade320c7',1,'Start::HelperFunctions']]],
  ['mean1d_2',['mean1D',['../class_start_1_1_helper_functions.html#ae35d9c1609c5d81c2f13030871737886',1,'Start::HelperFunctions']]]
];
