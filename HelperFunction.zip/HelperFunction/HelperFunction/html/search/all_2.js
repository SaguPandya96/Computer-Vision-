var searchData=
[
  ['start_3',['Start',['../namespace_start.html',1,'']]],
  ['sumofcols_4',['sumOfCols',['../class_start_1_1_helper_functions.html#a48b780804d64f1a9a74357527200381e',1,'Start::HelperFunctions']]],
  ['sumofrows_5',['sumOfRows',['../class_start_1_1_helper_functions.html#a5976987b506688b88f2c9fce5dc311e2',1,'Start::HelperFunctions']]]
];
