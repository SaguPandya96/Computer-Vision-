﻿/**
    \file   HelperFunction.cs
    \brief  Contains HelperFunction class definition.
    \author Sagar Pandya, M.S C.S, sp713159@sju.edu

   

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
    USA or from http://www.gnu.org/licenses/gpl.txt.

    This General Public License does not permit incorporating this
    code into proprietary programs.  (So a hypothetical company such
    as GH (Generally Hectic) should NOT incorporate this code into
    their proprietary programs.)
 */




/**
*HelperFunctions class that tests methods here 
*and prints the results to the console.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Start
{
    /** \brief  This class contains methods that read and write
     *  
     */
    class HelperFunctions
    {
        // input/read methods

        /** \brief  This method should be generally used to read any helper function
 
         *  \param  rows   will be take the rows
         *  \param  cols   will be take the cols
         *  \param Main method define here 
         */
        
        static void Main(string[] args)
        {

            //Set rows and cols here
            //take the rows 3
            //take the rows 3
            int rows = 3; 
            int cols = 3;

            //Intialize a 3d array here
            int[,] m ={ {1,0,0},
                        {0,1,0},
                        {0,0,1}};
            /** \brief  This function reads an Sum of rows 
         *
         *
         *  \param  rowsum  input sum of rows 
         *  \param  m      will be set to 3 dimensional array here
         *  \param  rows   will be set to rows 
         *  \param  cols   will be set to cols
         *
         *  \Define for loop define here 
         */
            int[] rowSum = sumOfRows(m, rows, cols);
            Console.WriteLine("Rows Sum ");
            for (int i = 0; i < rows; i++)
            {
                Console.WriteLine("Input Sum of rows Array : {0}", rowSum[i]);
            }

            /** \brief  This function reads an Sum of cols 
   *
   *
   *  \param  colssum  input sum of cols 
   *  \param  m       will be set to 3 dimensional array here
   *  \param  rows    will be set to rows 
   *  \param  cols    will be set to cols
   *
   *  \Define for loop  here 
   */
            int[] colsSum = sumOfCols(m, rows, cols);
            Console.WriteLine("Cols Sum ");
            for (int i = 0; i < rows; i++)
            {
                Console.WriteLine("Input Sum of cols Array : {0}", colsSum[i]);
            }

            //Array define in one dimensional 
            int[] D = { 1, 2, 3, 4, 5, 6 };

            Console.WriteLine("Mean of array elemenets : {0}", mean(m, rows, cols));
            Console.WriteLine("Mean of 1D array elements  : {0}", mean1D(D, 2, 3));
            Console.WriteLine("Trace of array : {0}", trace(m, rows, cols));

            Console.ReadKey();

        }
        /** \brief  calcualte the sum of the rows 
         * 
         *  \param  int[,]    define integer here m 
         *  \param  rows      will be set to rows value
         *  \param  cols      will be set to cols value 
        
         *  \returns  1d array returns here */
        public static int[] sumOfRows(int[,] m, int rows, int cols)
        {
            int[] sum = new int[rows];

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                    sum[i] += m[i, j];
            }

            return sum;
        }

        /** \brief  calcualte the sum of the columns
       * 
       *  \param  int[,]    define integer here m 
       *  \param  rows      will be set to rows value
       *  \param  cols      will be set to cols value 
      
       *  \returns  1d array returns here */
        
        public static int[] sumOfCols(int[,] m, int rows, int cols)
        {
            int[] sum = new int[rows];

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                    sum[i] += m[j, i];
            }

            return sum;
        }

        /** \brief  calcualte the mean of 2d of matrix average of elements here  
       * 
       *  \param  int[,]    define integer here m 
       *  \param  rows      will be set to rows value
       *  \param  cols      will be set to cols value 
      
       *  \returns  return the average  sum and count */
        public static double mean(int[,] m, int rows, int cols)
        {
            double sum = 0;
            int count = rows * cols;
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                    sum += m[j, i];
            }

            return sum / count;
        }

        /** \brief  Calculate mean of 1d of matrix(sum of elements)here
       * 
       *  \param  int[,]    define integer here m 
       *  \param  rows      will be set to rows value
       *  \param  cols      will be set to cols value 
      
       *  \returns  return the average  sum and count */
       
        public static double mean1D(int[] m, int rows, int cols)
        {
            double sum = 0;
            int count = rows * cols;
            for (int i = 0; i < rows * cols; i++)
            {
                sum += m[i];
            }

            return sum / count;
        }

        /** Calculate trace of matrix(sum of the diagonal matrix) here
      * 
      *  \param  int[,]    define integer here m 
      *  \param  rows      will be set to rows value
      *  \param  cols      will be set to cols value 
     
      *  \returns  return the sum function here */

        public static int trace(int[,] m, int rows, int cols)
        {
            int sum = 0;
            int count = rows * cols;
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                    if (i == j)
                        sum += m[i, j];
            }

            return sum;
        }
    }//end class

}//end namespace


